﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1_exercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double b;
            double h;
            double a;
            Console.Write("Digite o valor da base: ");
            b=int.Parse(Console.ReadLine());
            Console.Write("Digite o valor da altura: ");
            h=int.Parse(Console.ReadLine());
            a = b * h;
            Console.WriteLine("A área do retângulo é {0}", a);

        }
    }
}
